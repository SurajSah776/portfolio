// Testimonials component removed - not needed for personal portfolio
export default function Testimonials() {
  return null;
}